select ProductName,CompanyName,ContactName from
(select Product.ProductName as ProductName,Customer.CompanyName as CompanyName,
Customer.ContactName as ContactName, min(`Order`.OrderDate)
from `Order`,OrderDetail,Product,Customer
where Product.Discontinued = 1 and Product.Id = OrderDetail.ProductId and OrderDetail.OrderId = `Order`.Id 
and `Order`.CustomerId = Customer.Id
group by ProductName)
order by ProductName;
