with p as (select IFNULL(Customer.CompanyName,'MISSING_NAME') as CompanyName,
`Order`.CustomerId as CustomerId,round(sum(UnitPrice*Quantity),2) as expenditures,
NTILE(4) OVER (ORDER BY sum(UnitPrice*Quantity) asc) AS percentile
from `Order` left outer join Customer on Customer.Id = `Order`.CustomerId,OrderDetail
where  OrderDetail.OrderId = `Order`.Id
group by `Order`.CustomerId)

select CompanyName,CustomerId,expenditures
from p where percentile = 1
order by expenditures asc;
