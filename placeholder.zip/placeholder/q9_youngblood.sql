with p as (select Region.RegionDescription as RegionDescription,
Employee.FirstName as FirstName,Employee.LastName as LastName,
Employee.BirthDate as BirthDate,max(Employee.BirthDate)
from Employee,EmployeeTerritory,Territory,Region
where Employee.Id = EmployeeTerritory.EmployeeId and EmployeeTerritory.TerritoryId = 
Territory.Id and Territory.RegionId = Region.Id
group by Region.Id order by Region.Id)

select RegionDescription,FirstName,LastName,BirthDate
from p where BirthDate not NULL;