select A.CompanyName,round(A.ct*1.0/B.ct*100,2) as percent
from (select CompanyName,count(*) as ct from Shipper,`Order`  
where `Order`.ShipVia = Shipper.Id and ShippedDate > RequiredDate
group by CompanyName)A,
(select CompanyName,count(*) as ct from Shipper,`Order`  
where `Order`.ShipVia = Shipper.Id group by CompanyName)B
where A.CompanyName = B.CompanyName order by percent desc;