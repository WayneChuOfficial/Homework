select CategoryName,count(CategoryId),round(avg(UnitPrice),2),
min(UnitPrice),max(UnitPrice),sum(UnitsOnOrder)
from Category,Product
where Category.Id = Product.CategoryId
group by CategoryId
having count(CategoryId) > 10
order by CategoryId;