with p as (select Product.ProductName as ProductName,
row_number() over(order by Product.Id asc) as Num
from `Order`,Customer,OrderDetail,Product
where OrderDetail.OrderId = `Order`.Id and Product.Id = OrderDetail.ProductId and Customer.Id
= `Order`.CustomerId and Customer.CompanyName = 'Queen Cozinha' and `Order`.OrderDate
like '2014-12-25%'
order by Product.Id asc),

cteSource as (
select p1.ProductName ,p1.Num from p as p1 where p1.Num = 1
UNION
select cteSource.ProductName ||', '|| p2.ProductName,p2.Num from cteSource,p as p2
where p2.Num = cteSource.Num + 1)

select ProductName from cteSource order by Num desc limit 1;