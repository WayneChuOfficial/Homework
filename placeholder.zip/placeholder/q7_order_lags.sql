select Id,OrderDate, lag(OrderDate,1,OrderDate) over() 
,round(julianday(OrderDate)-julianday(lag(OrderDate,1,OrderDate) over()),2) as diff
from (select * from `Order` where CustomerId = 'BLONP' order by OrderDate asc limit 10)
order by OrderDate asc;