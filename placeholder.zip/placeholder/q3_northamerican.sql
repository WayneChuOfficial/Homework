select Id,ShipCountry,
case
when ShipCountry ='USA'or ShipCountry='Mexico' or ShipCountry ='Canada'
then 'NorthAmerica'
else 'OtherPlace'  
end as Whether 
from `Order`  
where Id >= 15445 order by Id asc limit 20;